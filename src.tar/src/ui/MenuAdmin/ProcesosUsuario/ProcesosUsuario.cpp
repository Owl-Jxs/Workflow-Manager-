#include "ProcesosUsuario.h"

void ProcesosUsuario::mostrarInformacionUsuario (Usuario* usuario) {
    std::string rol =((usuario->getRol() == Usuario::Rol::ADMINISTRADOR) ? "ADMINISTRADOR" : "USUARIO_NORMAL");
    std::cout << usuario->getId() << " | " << usuario->getNombre() << " | " << rol << std::endl;
} 


ProcesosUsuario::ProcesosUsuario (UsuarioController* _uc, Usuario* _uA, GestorHistorial* _gH) {
    this-> uc = _uc;
    this->usuarioActivo = _uA;
    this->gestorHistorial = _gH;

}

Usuario* ProcesosUsuario::leerNuevoUsuario() {
    int id;
    std::string nombre;
    int opcionRol;
    Usuario::Rol rol;
    Usuario* nuevoUsuario;
    id = ValidarEntrada::validarCodigoNumerico ("Ingrese su identificacion", 9);
    nombre =ValidarEntrada::validarNombreCompleto ();

    std::cout << "\nSeleccione el rol:\n";
    std::cout << "1. Administrador\n";
    std::cout << "2. Usuario Normal\n";
    opcionRol = ValidarEntrada::validarEntradaRango ("Ingrese su opcion", 1,2);

    switch (opcionRol) {
        case 1: {
            rol = Usuario::Rol::ADMINISTRADOR; break;
        }
        case 2: {
            rol = Usuario::Rol::USUARIO_NORMAL; break;
        }
        default: {
            rol = Usuario::Rol::USUARIO_NORMAL; break;
        }
    };
    
    nuevoUsuario = new Usuario (id, nombre, rol);
    std::string contrasena = ValidarEntrada::validarContrasena ("Ingrese la contrasena: ", '*');
    nuevoUsuario->setHashContrasena (contrasena);
    return nuevoUsuario;
}

void ProcesosUsuario::agregarUsuario  () {
    Usuario* usuario = leerNuevoUsuario();
    try {
        AgregarUsuarioComando* comandoAgregar = new AgregarUsuarioComando (uc,usuario);
        gestorHistorial->ejecutarComando (comandoAgregar);
        std::cout << "Usuario agregado correctamente.\n";

    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

void ProcesosUsuario::actualizarUsuario () {
    
    int id = ValidarEntrada::validarCodigoNumerico ("Ingrese el id del usuario buscado", 9);
    Usuario* usuarioActual = uc->buscarUsuarioPorId(id);
    if (usuarioActual == nullptr) {
        std::cout << "No existe un usuario con ese ID.\n";
        return;
    }

    Usuario* nuevoUsuario = new Usuario (usuarioActual);

   

    std::cout << "\nUsuario encontrado:\n";
    std::cout << "ID: " << usuarioActual->getId() << std::endl;
    std::cout << "Nombre: " << usuarioActual->getNombre() << std::endl;

    bool cambioNombre = ValidarEntrada::respuestas_Si_O_No ("Cambiar el nombre", "mantener nombre actual");
    if (cambioNombre) {
        std::string nuevoNombre = ValidarEntrada::validarNombreCompleto ();
        nuevoUsuario->setNombre (nuevoNombre);
    }

    bool cambioRol = ValidarEntrada::respuestas_Si_O_No ("Cambiar el rol", "mantener el Rol actual");
    if (cambioRol) {
        std::cout << "\nNuevo rol:\n";
        std::cout << "1. Administrador\n";
        std::cout << "2. Usuario Normal\n";
        int opcionRol = ValidarEntrada::validarEntradaRango ("Ingrese su opcion", 1,2);

        Usuario::Rol rol = ((opcionRol == 1) ? Usuario::Rol::ADMINISTRADOR : Usuario::Rol::USUARIO_NORMAL); 
        nuevoUsuario->setRol (rol);
    }

    bool cambioContrasena = ValidarEntrada::respuestas_Si_O_No ("Cambiar la contrasena", "Mantener actual");
    if (cambioContrasena) {
        std::string nuevaContra = ValidarEntrada::validarContrasena ("Ingrese su nueva contrasena", '*');
        nuevoUsuario->setHashContrasena (nuevaContra);
    }
    
    try {
        ActualizarUsuarioComando* actualizacion = new ActualizarUsuarioComando (uc, id, nuevoUsuario);
        gestorHistorial->ejecutarComando (actualizacion);
        std::cout << "Usuario actualizado" << std::endl;
    } catch (std::exception &e) {
        std::cout << "Error al actualizar usuario: " << e.what() << std::endl;
    }
}

void ProcesosUsuario::eliminarUsuario () {
    int id = ValidarEntrada::validarCodigoNumerico ("Digite el id del usuario", 9);
    Usuario* usuario = uc->buscarUsuarioPorId(id);

    if (usuario == nullptr) {
        std::cout << "No existe un usuario con ese ID.\n"; return;
    }

    std::cout << "\nUsuario encontrado:\n";
    std::cout << "ID: " << usuario->getId() << std::endl;
    std::cout << "Nombre: " << usuario->getNombre() << std::endl;
    std::cout << "¿Esta seguro de eliminarlo? \n";
    bool eliminarlo = ValidarEntrada::respuestas_Si_O_No ("Si", "No");
     
    if (eliminarlo) { 
        try {
            EliminarUsuarioComando* eliminar = new EliminarUsuarioComando (uc, id);
            gestorHistorial->ejecutarComando (eliminar);
            std::cout << "Usuario eliminado correctamente.\n";
        } catch (std::exception &e) {
            std::cout << "No se pudo eliminar el usuario: " << e.what() << "\n";
        }
    } else {
        std::cout << "Operacion cancelada.\n";
    }
}

void ProcesosUsuario::mostrarLista () {
    std::vector<Usuario*> usuarios = uc->listarUsuarios();
    if (usuarios.empty()) {
        std::cout << "No hay usuarios registrados.\n"; return;
    }  

    std::cout << "Que algoritmo de ordenamiento prefiere usar? " << std::endl
     << "1. QuickSort" << std::endl
     << "2. MergeSort" << std::endl 
     << "3. BubbleSort" << std::endl;
    int opcion = ValidarEntrada::validarEntradaRango ("Ingrese su opcion", 1,3);   
    
    std::cout << "Desea usar un ordenamiento ascendente o descendente? " << std::endl
     << "1. Ascendente" << std::endl
     << "2. Descendente" << std::endl; 
    int opcionOrden = ValidarEntrada::validarEntradaRango ("Ingrese su opcion", 1,2);   

    Icondicion<Usuario*> * condicion;
    if (opcionOrden == 1) {
        condicion = new ordenarUsuarioPorIdAscedente ();
    } else {
        condicion = new ordenarUsuarioPorIdDescendente ();
    }

    switch (opcion) {
        case 1:{    
        QuickSort<Usuario*>* algoritmo = new QuickSort<Usuario*> ();    algoritmo->ordenar (usuarios, condicion);
        delete algoritmo;
        break;
    }
    case 2:{
        MergeSort<Usuario*>* algoritmo = new MergeSort<Usuario*> ();     algoritmo->sort (usuarios, condicion);
        delete algoritmo;
        break;
    }
    case 3:{
        BubbleSort<Usuario*>* algoritmo = new BubbleSort<Usuario*> ();    algoritmo->sort (usuarios, condicion);
        delete algoritmo;
        break;
    }
    default:
        break;
    }

    delete condicion;
    std::cout << "\n========== LISTA DE USUARIOS ==========\n";
    for (Usuario* u : usuarios) {
        mostrarInformacionUsuario (u);
        std:: cout << "--------------------------------------------------------------------------------" << std::endl;
    }
}

void ProcesosUsuario::mostrarUsuarioPorId () {
    int id =  ValidarEntrada::validarCodigoNumerico ("Ingrese el id del usuario", 9);
    Usuario* usuario = uc->buscarUsuarioPorId(id);

    if (usuario == nullptr) {
        std::cout << "No existe un usuario con ese ID.\n"; return;
    }

    mostrarInformacionUsuario (usuario);  
}
